#include <stdio.h>
#include <stdlib.h>

int main() {
    // get an int from the user
    int i;
    scanf("%d", &i);
    printf("You entered: %d\n", i);
    return 0;
}