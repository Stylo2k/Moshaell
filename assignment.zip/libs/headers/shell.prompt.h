#ifndef PROMPT_SHELL_H
#define PROMPT_SHELL_H

void listenForCtrlL();
void listenForUpArrow();
void printPlainPrompt();
void listForBackspace();
void printShellPrompt();
void clearShell();

#endif