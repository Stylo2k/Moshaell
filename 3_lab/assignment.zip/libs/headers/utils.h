#ifndef UITLS_H
#define UITLS_H

void DEBUG(const char *fmt, ...);


#endif // UITLS_H
